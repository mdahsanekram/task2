import React, {Component} from 'react';
import { Redirect } from 'react-router-dom';
import HeadBarPage from './HeadBarPage';
import SideBarPage from './SideBarPage';
import './CSS/Home.css';

// import MenuItem from '@material-ui/core/MenuItem';
// import {Link} from 'react-router-dom';
// import 'bootstrap/dist/css/bootstrap.min.css';

class Home extends Component
{
    constructor(props)
    {
        super(props);
        this.state  = {
            loggedIn : true,
            data : []
        }
        const token = window.sessionStorage.getItem("userID");
        if(token === null || token === undefined)
        {
            this.state.loggedIn = false;
        }
    }

 logout= ()=>{
   
    window.sessionStorage.clear();
    this.setState({loggedIn : false});

    return <Redirect to="/" />

        }
        

  render()
  {

    if(this.state.loggedIn === false)
        {
            return <Redirect to="/"/>
        }
      return(
          <div >
          <div>
          <HeadBarPage/>
          </div>

              <div className="container-fluid">
              <div className="row">
              <div className="col-xl-2 sideBarClass">
              <SideBarPage/>

              </div>

              <div className="col-xl-10">
                    <h1 className="home">
                        Welcome in Shiksha 
                    </h1>
              </div>



              </div>
              
              </div>
              
          </div>

        )
    }
}


export default Home;