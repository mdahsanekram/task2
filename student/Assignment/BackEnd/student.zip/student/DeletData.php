<?php



include("DatabaseConn.php");

extract($_POST);

$query="DELETE from learner WHERE id='$userID'";
$res  = array();
$data =mysqli_query($conn, $query);

if($data === TRUE)
{
echo  json_encode(Sucess);
}

    
    
?>