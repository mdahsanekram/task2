<?php



include("DatabaseConn.php");

extract($_POST);

$query="UPDATE learner SET 
name='$name',
fname='$fname',
dob='$dob',
mob='$mob',
email='$email',
address='$address',
state='$state',
city='$city',
pin='$pin',
class='$class',
marks='$marks'
WHERE id='$userID'";
$data =mysqli_query($conn,$query);



if($data)
{
    
    echo "Data Update";
}
else
{
    echo "Not Update";
}
mysqli_close($conn);
    
    
?>