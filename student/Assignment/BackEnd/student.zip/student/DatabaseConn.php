<?php

 header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, DELETE, PUT, PATCH, OPTIONS');
header('Access-Control-Allow-Headers: token, Content-Type');
$servername = "localhost";
$username = "root";
$password = "";
$dbname ="student";


$conn = new mysqli($servername, $username, $password,$dbname);

 //echo "connection";
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";
?>