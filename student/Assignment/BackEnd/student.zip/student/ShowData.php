<?php

include("DatabaseConn.php");



$sql = "select * from learner";

$resp = array();

$response = array();
$res = mysqli_query($conn,$sql);


while($row = mysqli_fetch_assoc($res))
{
    
    $response  []  = array(
    
        
        "id"=>$row['id'],
        "name"=>$row['name'],
        "fname"=>$row['fname'],  
        "dob"=>$row['dob'],
        "mob"=>$row['mob'],
        "email"=>$row['email'],
        "class"=>$row['class'],
        "address"=>$row['address'],
        "city"=>$row['city'],
        "state"=>$row['state'],
        "pin"=>$row['pin'],        
        "marks"=>$row['marks'],
        
    
    );
    
}

echo  json_encode($response);

?>