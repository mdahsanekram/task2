<?php





include("DatabaseConn.php");

extract($_POST);

$query="Select * from learner WHERE Id='$userID'";
$response  = array();
$data =mysqli_query($conn, $query);

while($row = mysqli_fetch_assoc($data))
{
    
    $response [] = array(
    
        
        "Id"=>$row['id'],
        "name"=>$row['name'],
        "fname"=>$row['fname'],
        "mob"=>$row['mob'],
        "email"=>$row['email'],
        "dob"=>$row['dob'],
        "class"=>$row['class'],
        "state"=>$row['state'],
        "address"=>$row['address'],
        "city"=>$row['city'],
        "pin"=>$row['pin'],
        "marks"=>$row['marks'],
    
    );
    
}

echo json_encode($response);
    
    
?>