        <?php

include("DatabaseConn.php");


extract($_POST);


$query="INSERT INTO learner (name,fname,mob,email,class,dob,address,city,state,pin,marks) VALUES ('$name','$fname','$mob','$email','$class','$dob','$address','$city','$state','$pin','$marks')";
$data =mysqli_query($conn, $query);


if($data)
{
    
    echo "Data Inserted";
}
else
{
    mysqli_error($conn);
    
}
mysqli_close($conn);
?>

