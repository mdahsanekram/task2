import React, {Component} from 'react';
import './CSS/HeaderFile.css';
class HeadBarPage extends Component
{
    render()
  {
    return(
      <div className="container-fluid">
      <div className="row">
      <div className=" col-md-12 col-sm-12 hed">
      </div>

      </div>

      </div>

    )
}
}


export default HeadBarPage;