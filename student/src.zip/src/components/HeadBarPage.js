import React, {Component} from 'react';
import './CSS/HeaderFile.css';
class HeadBarPage extends Component
{
    render()
  {
    return(
      <div className="container-fluid">
      <div className="row">
      <div className="col-sx-2 col-md-2 col-sm-2 hedm">


      </div>
      <div className=" col-md-10 col-sm-10 hed">
      


      </div>

      </div>

      </div>

    )
}
}


export default HeadBarPage;