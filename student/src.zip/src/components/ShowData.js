// https://www.youtube.com/watch?v=6QvNCZQWDZk
import React, {Component, useState} from 'react';
import { Redirect } from 'react-router-dom';
import HeadBarPage from './HeadBarPage';
import SideBarPage from './SideBarPage';
import {Modal,Button} from 'react-bootstrap';
import './CSS/ShowData.css';
import axios from 'axios';
import { faDeaf, faEdit,  faEye, faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import "datatables.net-dt/js/dataTables.dataTables";

import ReactPaginate from 'react-paginate';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'jquery/dist/jquery.min.js';
import "datatables.net-dt/css/jquery.dataTables.min.css";
import './CSS/ShowData.css';
class ShowData extends Component
{
    constructor(props)
    {
        super(props);

        this.state  = {
          show : false,
          show1:false,
          loggedIn : true,
          data : [],
          cols:[],
          offset: 0,
          tableData: [],
          orgtableData: [],
          perPage: 9,
          currentPage: 0,
          isVarified : false,
            name   : "",
            school   : "",
            dob     : "",
            class  : "",
            divison   : "",
            status : "",            
           
           
            userID : 0,
      }
      //  this.handleChange = this.handleChange.bind(this);   
       const token = window.sessionStorage.getItem("userID");

      console.log("showtoc:",token);

      if(token === null || token === undefined)
      {
          this.state.loggedIn = false;
      }

      // this.handlePageClick = this.handlePageClick.bind(this);
      }

  handlePageClick = (e) => {
    const selectedPage = e.selected;
    const offset = selectedPage * this.state.perPage;

    this.setState({
        currentPage: selectedPage,
        offset: offset
    }, () => {
        this.loadMoreData()
    });

};

loadMoreData() {
const data = this.state.orgtableData;

const slice = data.slice(this.state.offset, this.state.offset + this.state.perPage)
this.setState({
  pageCount: Math.ceil(data.length / this.state.perPage),
  tableData:slice
})

}


setQ(q) {
  this.props.onChange(q);
}





logout= ()=>{
 
  window.sessionStorage.clear();
  this.setState({loggedIn : false});
  

  return <Redirect to="/" />

      } 

    componentDidMount()
    {       

        
        axios.post('http://localhost/student/ShowUser.php')
        
            .then((response)=>{
               
              this.setState({data: response.data, cols:  response.data.cols});
              var tdata = response.data;
               
				        var slice = tdata.slice(this.state.offset, this.state.offset + this.state.perPage)
                this.setState({
                    pageCount: Math.ceil(tdata.length / this.state.perPage),
                    orgtableData : tdata,
                    tableData:slice
                });
                
            }).catch(function(error)
            {
                alert(error);
            })

    }
setQ=()=>{
  return this.state.value=this.state.user;
}


  handleModal = () =>{

      this.setState({show:!this.state.show});
      console.log("click")
  }

  handleModal2 = () =>{

    this.setState({show1: !this.state.show1});
  }



  handleModalGetData = (userID) =>
  {
                let formData = new FormData();
                
                formData.append("userID",userID);
                formData.append('name',this.state.name);
			          formData.append('school',this.state.school);
                formData.append('dob',this.state.dob);
			          formData.append('class',this.state.class);
		          	formData.append('divison',this.state.divison);
                formData.append('status',this.state.status);
                
            
                


    axios.post('http://localhost/student/EditData.php',formData)
    .then((response)=>{
      

              //  console.log(response.data[0].school);

               this.state.userID = response.data[0].userID;  

               this.state.name=response.data[0].name;
               this.state.school=response.data[0].school;
               this.state.dob=response.data[0].dob;
               this.state.class=response.data[0].class;
               this.state.divison=response.data[0].divison;
               this.state.status=response.data[0].status;    

               this.setState({show:!this.state.show}); 

      }).catch(function(error)
      {
        alert(error);
      });
  }

  submitModal =()=>{
    let formData = new FormData();

                formData.append("userID",this.state.userID);               
		         
                formData.append('name',this.state.name);
			          formData.append('school',this.state.school);
                formData.append('dob',this.state.dob);
			          formData.append('class',this.state.class);
		          	formData.append('divison',this.state.divison);
                formData.append('status',this.state.status);
            
                


          axios.post('http://localhost/student/updateUser.php',formData)
          .then((response)=>{
                  
                 
          if(response.data === "Data Update")
          {
           
            // this.setState({signlg : true});
            this.setState({loggedIn : true});

            this.setState({show: !this.state.show});

            this.componentDidMount();


          }
          else
          {
            this.setState({loggedIn :false});
          }
        }).catch(function(error){
          alert(error)
        })
  }

  keyPress(e){
   
          // if(e.keyCode == 13){
    
          //   this.setState({    
          //       loading: true    
          //   });
    
          //   this.setState({
          //  searchQuery:e.target.value
   
          //   });
             
    
          //   let test_type = this.state.test_type !==undefined ? this.state.test_type : '';     
          //   let url = constant.APP_URL+'api/get-student?searchColumn=name&searchQuery='+e.target.value+'&test_type='+test_type;
          //   this.getCallApi(url);   
          //   this.setState({    
          //  loading: false
    
          //   });
    
          // }
    
        }
    

  handleModalGetData2 = (userID) =>
  {
   
    
    let formData = new FormData();
    formData.append("userID",userID);
                
    axios.post('http://localhost/student/EditData.php',formData)
    .then((response)=>{
               

               this.state.userID = response.data[0].userID;               
               this.state.name=response.data[0].name;
               this.state.school=response.data[0].school;
               this.state.dob=response.data[0].dob;
               this.state.class=response.data[0].class;
               this.state.divison=response.data[0].divison;
               this.state.status=response.data[0].status;
              

               

               this.setState({show1: !this.state.show1});               
      }).catch(function(error)
      {
        alert(error);
      });
  }

  handleChange(e) {
    this.emitChangeDebounced(e.target.value);
  }

  handleChnage = (event) =>{

    this.setState( {  [event.target.name] : event.target.value } )

  }

  emitChange(value) {
    this.props.onChange(value);
  }
    render()
  {
   


    if(this.state.loggedIn === false)
        {   
            return <Redirect to="/"/>
        }
    return(
        <div >
          <div>
          <HeadBarPage/>
          </div>

              <div className="container-fluid">
              <div className="row">
              <div className="col-xl-2 sideBarClass">
              <SideBarPage/>

              </div>              

              <div className="col-xl-10 mb-3 mt-3 tbl">
              {/* <div class="jumbotron text-center">
                   <h3>Therichpost.com</h3>
               </div> */}

              <div className="search">
                <input type="Search!" placeholder="Search.." value={this.state.user} onClick={()=>this.setQ()}
                
             
                />
    
              </div>


                   <table className="table table-striped table-bordered table-sm row-border hover ">  
                      <thead>  
                        <tr>
                          <th scope="col">Id </th>
                          <th scope="col">Name</th>
                          <th scope="col">DOB</th>
                          <th scope="col">School</th>
                          <th scope="col">Class</th>
                          <th scope="col">Divison</th>
                          <th scope="col">Status</th>
                          <th scope="col">Action</th> 
                        </tr>
                      </thead>
                      {/* <TableContainer>

                      </TableContainer> */}

                      <tbody>
                        {
                        
                            this.state.tableData.map((user,index)=>(
                            
                                <tr key={user.Id}>
                                   <td>{user.Id}</td>
                                    <td>{user.name} </td>
                                    <td>{user.dob}</td>
                                    <td>{user.school}</td>
                                    <td>{user.class}</td>
                                    <td>{user.divison} </td>
                                    <td>{user.status}</td>
                                    
                                    <td >
                                      {/* <Link to={{ pathname:"/EditUser", 
                                      editProps:{editData: user.Id} }} className="btn btn-primary mr-2"><FontAwesomeIcon icon={faEdit} /></Link> */}
                                       {/* {() => setModalShow(true)} */}
                                      <Button type="button" className="btn btn-outline-secondary mr-2" onClick={()=>this.handleModalGetData(user.Id)}>
                                      <FontAwesomeIcon icon={faEdit} />
                                      </Button>                                                                       
                                        
                                      {/* <Button type="button" className="btn btn-light mr-2" onClick={()=>this.handleModalGetData2(user.Id)} >
                                      <FontAwesomeIcon icon={faEye} />
                                      </Button> */}

                                      <Button type="button" className="btn btn-danger mr-2" onClick={()=>this.handleModalGetData3(user.Id)} >
                                      <FontAwesomeIcon icon={faTrashAlt} />
                                      </Button>

                                      
                                     </td>               
                            
                                </tr>
                            ))
                            
                        }
                      </tbody>
                    </table>

                    <ReactPaginate
                    previousLabel={"prev"}
                    nextLabel={"next"}
                    breakLabel={"..."}
                    breakClassName={"break-me"}
                    pageCount={this.state.pageCount}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={5}
                    onPageChange={this.handlePageClick}
                    containerClassName={"pagination"}
                    subContainerClassName={"pages pagination"}
                    activeClassName={"active"}/>



              </div>
            </div>              
          </div>
          {/*  Edit Start Model */}

          <div id="exampleModal">
          <Modal size="lg" show={this.state.show}  onHide={()=>this.handleModal()}>
                <Modal.Header closeButton>
                <Modal.Title>Edit User  </Modal.Title>
               </Modal.Header>
              <Modal.Body>
              <div className="container">
                <div className="row">  
                  <div className="col-md-6">
                    <div className="form-group">
                      <input
                      type="text"
                      className="form-control form-control-lg"
                      placeholder="Enter Name"
                      name="name"  
                      value={this.state.name}   
                      onChange={this.handleChnage}                    
                      />
                  </div>
                </div>
  
                 <div className="col-md-6">
                    <div className="form-group">
                      <input
                      type="text"
                      className="form-control form-control-lg"
                      placeholder="Enter Date"
                      name="dob"
                      value={this.state.dob}   
                      onChange={this.handleChnage}                     
                   />
                  </div>
                </div>

                <div className="col-md-6">
                    <div className="form-group">
                      <input
                      type="text"
                      className="form-control form-control-lg"
                      placeholder="Enter Class"
                      name="class"
                      value={this.state.class}   
                      onChange={this.handleChnage}              
                   />
                  </div>
                </div>

                <div className="col-md-6">
                    <div className="form-group">
                      <input
                      type="text"
                      className="form-control form-control-lg"
                      placeholder="Enter School"
                      name="school"
                      value={this.state.school}   
                      onChange={this.handleChnage}                    
                   />
                  </div>
                </div>


                <div className="col-md-6">
                    <div className="form-group">
                      <input
                      type="text"
                      className="form-control form-control-lg"
                      placeholder="Enter Divison"
                      name="divison"
                      value={this.state.divison}   
                      onChange={this.handleChnage}                     
                   />
                  </div>
                </div>

                <div className="col-md-6">
                    <div className="form-group">
                      <input
                      type="text"
                      className="form-control form-control-lg"
                      placeholder="Enter Status"
                      name="status"
                      value={this.state.status}   
                      onChange={this.handleChnage}                    
                   />
                  </div>
                </div>

              
  
            </div>
            </div> 
                         
            
            </Modal.Body>
            <Modal.Footer>
              
              <Button variant="primary" onClick={()=>this.submitModal()}> Save Changes</Button>

              <Button onClick={()=>this.handleModal()} variant="secondary">Close</Button>
            </Modal.Footer>
          </Modal>
          </div>  
   {/*  End Edit Model */}


   {/* Start Show Data */}

   <div id="showModal">
          <Modal size="lg" show={this.state.show1} onHide={()=>this.handleModal2()}>
                <Modal.Header closeButton>
                  <Modal.Title>User Id: {this.state.userID}</Modal.Title>
               </Modal.Header>
              <Modal.Body>
                  
              <div className="container-fluid">
                <div className="row">
                  <div className="col-md-6">
                      
                  <ul className="list-group w-70">
                  <li className="list-group-item">Full Name:{this.state.name}</li>
                  <li className="list-group-item">DOB:{this.state.dob}</li>                  
                  <li className="list-group-item">Divison: {this.state.divison}</li>
                  
                  
                  
                 
                </ul>

                  </div>
                  <div className="col-md-6">
                    
                  <ul className="list-group w-70">
                                    
                  <li className="list-group-item">School :{this.state.school}</li>
                  <li className="list-group-item">Class: {this.state.class}</li>
                  <li className="list-group-item">Status: {this.state.status}</li>
                
                  
                </ul>

                  </div>
                </div>
              </div>      
                
                      
            </Modal.Body>
            <Modal.Footer>              
              
              <Button onClick={()=>this.handleModal2()} variant="secondary">Close</Button>
            </Modal.Footer>
          </Modal>
          </div> 
    {/* End Show Model */}
   

         </div>        
        )
      }
    }

export default ShowData;
