import logo from './logo.svg';
import './App.css';
import {BrowserRouter,Switch ,Route } from 'react-router-dom';
import LoginForm from './components/LoginForm';
import Registration from './components/Registration';
import Home from './components/Home';
import SideBarPage from './components/SideBarPage';
import HeadBarPage from './components/HeadBarPage';
import AddUser from './components/AddUser';
import ShowData from './components/ShowData';


function App() {
  return (
    <BrowserRouter>
    <div className="App">

    <Switch>
    
      <Route path="/" exact component={LoginForm}></Route>
     
      <Route path="/Registration"  exact component={Registration} ></Route>
      <Route path="/Home"  exact component={Home} ></Route>
      <Route path="/SideBarPage"  exact component={SideBarPage} ></Route>
      <Route path="/HeadBarPage"  exact component={HeadBarPage} ></Route>
      <Route path="/AddUser"  exact component={AddUser} ></Route>
      <Route path="/ShowData"  exact component={ShowData} ></Route>
  </Switch>
    </div>

    </BrowserRouter>
  );
}

export default App;
